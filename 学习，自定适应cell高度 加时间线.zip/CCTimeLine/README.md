# CCTimeLine
资讯时间轴，支持折叠和展开，支持踩赞

![image](https://github.com/CCBrother/CCTimeLine/blob/master/timeLineGif.gif)
